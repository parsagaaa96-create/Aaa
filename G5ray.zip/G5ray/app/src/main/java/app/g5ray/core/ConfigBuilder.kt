package app.g5ray.core

import org.json.JSONObject

/** Builds a sing-box (v1.10.x) config. All DNS goes through the tunnel using DoH; only the proxy server's own
 *  hostname is resolved via DoT on the direct path (needed to avoid a connect loop). */
object ConfigBuilder {
    fun build(p: Parsed): String {
        val isIp = p.host.contains(':') || p.host.matches(Regex("^[0-9.]+$"))
        val dnsRules = if (isIp) emptyList() else listOf(mapOf("domain" to listOf(p.host), "server" to "bootstrap"))
        val cfg = mapOf(
            "log" to mapOf("level" to "error"),
            "dns" to mapOf(
                "servers" to listOf(
                    mapOf("tag" to "remote", "address" to "https://1.1.1.1/dns-query", "detour" to "proxy"),
                    mapOf("tag" to "bootstrap", "address" to "tls://1.1.1.1", "detour" to "direct")
                ),
                "rules" to dnsRules, "final" to "remote", "strategy" to "prefer_ipv4", "independent_cache" to true
            ),
            "inbounds" to listOf(mapOf(
                "type" to "tun", "tag" to "tun-in", "interface_name" to "tun0",
                "inet4_address" to "172.19.0.1/30", "inet6_address" to "fdfe:dcba:9876::1/126",
                "mtu" to 1400, "auto_route" to true, "stack" to "mixed", "sniff" to true
            )),
            "outbounds" to listOf(
                p.outbound,
                mapOf("type" to "direct", "tag" to "direct"),
                mapOf("type" to "dns", "tag" to "dns-out")
            ),
            "route" to mapOf(
                "rules" to listOf(
                    mapOf("protocol" to "dns", "outbound" to "dns-out"),
                    mapOf("ip_is_private" to true, "outbound" to "direct")
                ),
                "final" to "proxy", "auto_detect_interface" to true
            )
        )
        return JSONObject(cfg).toString()
    }
}
