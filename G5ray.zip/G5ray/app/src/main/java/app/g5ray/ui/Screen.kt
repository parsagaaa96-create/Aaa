package app.g5ray.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.g5ray.R
import app.g5ray.vpn.VpnState
import app.g5ray.vpn.VpnStatus

private val BG = Color(0xFF0E1116)
private val Card = Color(0xFF181D25)
private val Muted = Color(0xFF8B95A5)

@Composable
fun G5Theme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Color(0xFF3B82F6), background = BG, surface = Card), content = content
)

@Composable
fun Screen(
    vm: MainVM, onToggle: () -> Unit, onClipboard: () -> Unit, onQr: () -> Unit,
    onFile: () -> Unit, onLang: () -> Unit, onImportText: (String) -> Unit
) {
    val st by VpnState.flow.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val smart by vm.smart.collectAsStateWithLifecycle()
    val latency by vm.latency.collectAsStateWithLifecycle()
    val testing by vm.testing.collectAsStateWithLifecycle()
    var showLink by remember { mutableStateOf(false) }
    val s = st
    val active = s is VpnStatus.Connected || s is VpnStatus.Connecting

    val label = when {
        testing -> stringResource(R.string.status_testing)
        s is VpnStatus.Connecting -> stringResource(R.string.status_connecting)
        s is VpnStatus.Connected -> stringResource(R.string.status_connected, s.name)
        s is VpnStatus.Error -> stringResource(s.msgRes)
        else -> stringResource(R.string.status_disconnected)
    }
    val color = when (s) {
        is VpnStatus.Connected -> Color(0xFF22C55E)
        is VpnStatus.Connecting -> Color(0xFFF59E0B)
        is VpnStatus.Error -> Color(0xFFEF4444)
        else -> Color(0xFF3B82F6)
    }

    Column(Modifier.fillMaxSize().background(BG).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("G5ray", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onLang) { Text(stringResource(R.string.lang_switch)) }
        }
        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(140.dp).clip(CircleShape).background(color.copy(alpha = if (testing) 0.4f else 1f))
                    .clickable(enabled = !testing, onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                Text(stringResource(if (active) R.string.disconnect else R.string.connect),
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(label, color = Color.White, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.smart), color = Color.White)
                Text(stringResource(R.string.smart_desc), color = Muted, fontSize = 12.sp)
            }
            Switch(checked = smart, onCheckedChange = vm::setSmart, enabled = !active)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(R.string.imp_clipboard to onClipboard, R.string.imp_link to { showLink = true },
                R.string.imp_qr to onQr, R.string.imp_file to onFile).forEach { (r, f) ->
                OutlinedButton(onClick = f, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                    Text(stringResource(r), fontSize = 12.sp, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (profiles.isEmpty()) {
            Text(stringResource(R.string.empty), color = Muted, modifier = Modifier.weight(1f).padding(24.dp), textAlign = TextAlign.Center)
        } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(profiles, key = { it.id }) { p ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (!smart) RadioButton(selected = p.id == selected, onClick = { vm.select(p.id) }, enabled = !active)
                    Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                        Text(p.name, color = Color.White, maxLines = 1)
                        Text("${p.protocol} · ${p.host}:${p.port}", color = Muted, fontSize = 12.sp, maxLines = 1)
                    }
                    latency[p.id]?.let { Text("$it ms", color = Color(0xFF22C55E), fontSize = 12.sp) }
                    TextButton(onClick = { vm.remove(p.id) }, enabled = !active) { Text(stringResource(R.string.delete), fontSize = 12.sp) }
                }
            }
        }
        Text(stringResource(R.string.footer), color = Muted, fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center)
    }

    if (showLink) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showLink = false },
            title = { Text(stringResource(R.string.paste_title)) },
            text = { OutlinedTextField(text, { text = it }, minLines = 3) },
            confirmButton = { TextButton({ onImportText(text); showLink = false }) { Text(stringResource(R.string.ok)) } },
            dismissButton = { TextButton({ showLink = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
