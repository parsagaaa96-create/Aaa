package app.g5ray

import android.app.Application
import app.g5ray.data.Store

class G5App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}
