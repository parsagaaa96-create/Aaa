package app.g5ray.vpn

import kotlinx.coroutines.flow.MutableStateFlow

sealed interface VpnStatus {
    object Disconnected : VpnStatus
    data class Connecting(val name: String) : VpnStatus
    data class Connected(val name: String) : VpnStatus
    data class Error(val msgRes: Int) : VpnStatus
}

/** "Connected" is only ever set after the core started AND a real HTTPS probe through the tunnel succeeded. */
object VpnState {
    val flow = MutableStateFlow<VpnStatus>(VpnStatus.Disconnected)
}
