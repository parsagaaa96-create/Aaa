package app.g5ray.ui

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.lifecycleScope
import app.g5ray.R
import app.g5ray.vpn.G5VpnService
import app.g5ray.vpn.VpnState
import app.g5ray.vpn.VpnStatus
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val vm: MainVM by viewModels()
    private var pending: List<String>? = null

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val ids = pending; pending = null
        if (r.resultCode == RESULT_OK && ids != null) startVpn(ids)
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val qr = registerForActivityResult(ScanContract()) { r -> r.contents?.let { report(vm.import(it)) } }
    private val filePick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { readFile(it)?.let { t -> report(vm.import(t)) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        handleIntent(intent)
        setContent {
            G5Theme {
                Screen(vm, ::toggle, ::fromClipboard, { qr.launch(ScanOptions().setBeepEnabled(false).setOrientationLocked(false).setPrompt("")) },
                    { filePick.launch(arrayOf("*/*")) }, ::switchLanguage) { report(vm.import(it)) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.dataString?.let { report(vm.import(it)) }
    }

    private fun report(n: Int) = Toast.makeText(this,
        if (n > 0) getString(R.string.imported, n) else getString(R.string.import_failed), Toast.LENGTH_SHORT).show()

    private fun fromClipboard() {
        val t = getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        report(vm.import(t))
    }

    private fun readFile(uri: Uri): String? = runCatching {
        contentResolver.openInputStream(uri)?.use { it.readBytes().take(1_000_000).toByteArray().decodeToString() }
    }.getOrNull()

    private fun switchLanguage() {
        val cur = AppCompatDelegate.getApplicationLocales()
        val lang = if (!cur.isEmpty) cur[0]?.language else resources.configuration.locales[0].language
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(if (lang == "fa") "en" else "fa"))
    }

    private fun toggle() {
        when (VpnState.flow.value) {
            is VpnStatus.Connected, is VpnStatus.Connecting ->
                startService(Intent(this, G5VpnService::class.java).setAction(G5VpnService.ACTION_STOP))
            else -> lifecycleScope.launch {
                val ids = vm.rank()
                if (ids.isEmpty()) { Toast.makeText(this@MainActivity, R.string.err_no_server, Toast.LENGTH_SHORT).show(); return@launch }
                val i = VpnService.prepare(this@MainActivity)
                if (i == null) startVpn(ids) else { pending = ids; vpnPermission.launch(i) }
            }
        }
    }

    private fun startVpn(ids: List<String>) {
        ContextCompat.startForegroundService(this, Intent(this, G5VpnService::class.java)
            .setAction(G5VpnService.ACTION_START).putExtra(G5VpnService.EXTRA_IDS, ids.toTypedArray()))
    }
}
