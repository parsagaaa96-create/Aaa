package app.g5ray.core

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

class Parsed(val name: String, val protocol: String, val host: String, val port: Int, val outbound: JSONObject) {
    var raw: String = ""
}

/** Parses vless://, vmess://, wireguard:// links and WireGuard .conf files into sing-box outbounds. */
object Parser {
    fun parseAll(text: String): List<Parsed> {
        val t = text.trim()
        if (t.contains("[Interface]", true)) {
            return listOfNotNull(runCatching { wgConf(t).also { it.raw = t } }.getOrNull())
        }
        return t.lines().map { it.trim() }.filter { it.isNotEmpty() }
            .mapNotNull { l -> runCatching { parseLink(l).also { it.raw = l } }.getOrNull() }
    }

    private fun parseLink(s: String): Parsed = when {
        s.startsWith("vless://", true) -> vless(s)
        s.startsWith("vmess://", true) -> vmess(s)
        s.startsWith("wireguard://", true) || s.startsWith("wg://", true) -> wgLink(s)
        else -> throw IllegalArgumentException("unsupported")
    }

    private fun b64(s: String): String {
        val x = s.trim().replace('-', '+').replace('_', '/')
        return String(Base64.decode(x.padEnd((x.length + 3) / 4 * 4, '='), Base64.DEFAULT))
    }

    private fun name(frag: String?, fallback: String) = Uri.decode(frag)?.takeIf { it.isNotBlank() } ?: fallback

    private fun vless(s: String): Parsed {
        val u = Uri.parse(s)
        val host = u.host ?: error("host")
        val port = u.port.takeIf { it in 1..65535 } ?: error("port")
        val ob = JSONObject().put("type", "vless").put("tag", "proxy").put("server", host)
            .put("server_port", port).put("uuid", u.userInfo ?: error("uuid")).put("packet_encoding", "xudp")
        u.getQueryParameter("flow")?.takeIf { it.isNotEmpty() }?.let { ob.put("flow", it) }
        transport(ob, u.getQueryParameter("type"), u.getQueryParameter("host"),
            u.getQueryParameter("path"), u.getQueryParameter("serviceName"))
        tls(ob, u.getQueryParameter("security"),
            u.getQueryParameter("sni") ?: u.getQueryParameter("host") ?: host,
            u.getQueryParameter("fp"), u.getQueryParameter("alpn"),
            u.getQueryParameter("pbk"), u.getQueryParameter("sid"))
        return Parsed(name(u.fragment, "VLESS $host"), "VLESS", host, port, ob)
    }

    private fun vmess(s: String): Parsed {
        val j = JSONObject(b64(s.substring(8)))
        val host = j.getString("add")
        val port = j.get("port").toString().toInt()
        val ob = JSONObject().put("type", "vmess").put("tag", "proxy").put("server", host)
            .put("server_port", port).put("uuid", j.getString("id"))
            .put("security", j.optString("scy").ifEmpty { "auto" })
            .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0).put("packet_encoding", "xudp")
        transport(ob, j.optString("net"), j.optString("host"), j.optString("path"), j.optString("path"))
        tls(ob, if (j.optString("tls") == "tls") "tls" else null,
            j.optString("sni").ifEmpty { j.optString("host").ifEmpty { host } },
            j.optString("fp"), j.optString("alpn"), null, null)
        return Parsed(j.optString("ps").ifBlank { "VMess $host" }, "VMess", host, port, ob)
    }

    private fun wgLink(s: String): Parsed {
        val u = Uri.parse(s.replaceFirst("wg://", "wireguard://", true))
        val host = u.host ?: error("host")
        val port = u.port.takeIf { it in 1..65535 } ?: error("port")
        val addr = (u.getQueryParameter("address") ?: error("address")).split(',').map { it.trim() }
        val res = u.getQueryParameter("reserved")?.split(',')?.map { it.trim().toInt() }
        val ob = wgOutbound(host, port, u.userInfo ?: error("key"),
            u.getQueryParameter("publickey") ?: u.getQueryParameter("peer_public_key") ?: error("pub"),
            u.getQueryParameter("presharedkey"), addr, u.getQueryParameter("mtu")?.toIntOrNull(), res)
        return Parsed(name(u.fragment, "WireGuard $host"), "WireGuard", host, port, ob)
    }

    private fun wgConf(t: String): Parsed {
        val kv = mutableMapOf<String, String>()
        var sec = ""
        t.lines().forEach { l ->
            val x = l.substringBefore('#').trim()
            if (x.startsWith("[")) sec = x.trim('[', ']').lowercase()
            else if ('=' in x) kv.putIfAbsent(sec + "." + x.substringBefore('=').trim().lowercase(), x.substringAfter('=').trim())
        }
        val ep = kv["peer.endpoint"] ?: error("endpoint")
        val host = ep.substringBeforeLast(':').trim('[', ']')
        val port = ep.substringAfterLast(':').toInt()
        val ob = wgOutbound(host, port, kv["interface.privatekey"] ?: error("key"),
            kv["peer.publickey"] ?: error("pub"), kv["peer.presharedkey"],
            (kv["interface.address"] ?: error("address")).split(',').map { it.trim() },
            kv["interface.mtu"]?.toIntOrNull(), null)
        return Parsed("WireGuard $host", "WireGuard", host, port, ob)
    }

    private fun wgOutbound(host: String, port: Int, priv: String, pub: String, psk: String?,
                           addr: List<String>, mtu: Int?, reserved: List<Int>?): JSONObject {
        val ob = JSONObject().put("type", "wireguard").put("tag", "proxy").put("server", host)
            .put("server_port", port).put("local_address", JSONArray(addr))
            .put("private_key", priv).put("peer_public_key", pub).put("mtu", mtu ?: 1280)
        if (!psk.isNullOrEmpty()) ob.put("pre_shared_key", psk)
        if (reserved != null) ob.put("reserved", JSONArray(reserved))
        return ob
    }

    private fun transport(ob: JSONObject, type: String?, host: String?, path: String?, svc: String?) {
        val p = path?.ifEmpty { null } ?: "/"
        val t = when (type) {
            "ws" -> JSONObject().put("type", "ws").put("path", p).also {
                if (!host.isNullOrEmpty()) it.put("headers", JSONObject().put("Host", host))
            }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", svc ?: path ?: "")
            "http", "h2" -> JSONObject().put("type", "http").put("path", p).also {
                if (!host.isNullOrEmpty()) it.put("host", JSONArray(host.split(',')))
            }
            "httpupgrade" -> JSONObject().put("type", "httpupgrade").put("path", p).also {
                if (!host.isNullOrEmpty()) it.put("host", host)
            }
            else -> null
        }
        if (t != null) ob.put("transport", t)
    }

    /** Certificate verification is always on: "allowInsecure"/"insecure" link parameters are deliberately ignored. */
    private fun tls(ob: JSONObject, sec: String?, sni: String, fp: String?, alpn: String?, pbk: String?, sid: String?) {
        if (sec != "tls" && sec != "reality") return
        val t = JSONObject().put("enabled", true).put("server_name", sni)
        if (!alpn.isNullOrEmpty()) t.put("alpn", JSONArray(alpn.split(',')))
        if (sec == "reality") {
            t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp?.ifEmpty { null } ?: "chrome"))
            t.put("reality", JSONObject().put("enabled", true).put("public_key", pbk ?: error("pbk")).put("short_id", sid ?: ""))
        } else if (!fp.isNullOrEmpty()) {
            t.put("utls", JSONObject().put("enabled", true).put("fingerprint", fp))
        }
        ob.put("tls", t)
    }
}
