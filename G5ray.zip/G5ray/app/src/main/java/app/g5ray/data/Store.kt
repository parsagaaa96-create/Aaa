package app.g5ray.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** [raw] holds the original link/config including secrets; it is only ever stored encrypted (Android Keystore). */
data class Profile(
    val id: String, val name: String, val raw: String, val protocol: String,
    val host: String, val port: Int, val ok: Int = 0, val fail: Int = 0
)

object Store {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        val key = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        sp = EncryptedSharedPreferences.create(
            c, "g5_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    @Synchronized fun load(): List<Profile> = runCatching {
        val a = JSONArray(sp.getString("profiles", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Profile(o.getString("id"), o.getString("name"), o.getString("raw"), o.getString("proto"),
                o.getString("host"), o.getInt("port"), o.optInt("ok"), o.optInt("fail"))
        }
    }.getOrDefault(emptyList())

    @Synchronized fun save(l: List<Profile>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("raw", it.raw).put("proto", it.protocol)
                .put("host", it.host).put("port", it.port).put("ok", it.ok).put("fail", it.fail))
        }
        sp.edit().putString("profiles", a.toString()).apply()
    }

    @Synchronized fun record(id: String, success: Boolean) = save(load().map {
        if (it.id != id) it else if (success) it.copy(ok = it.ok + 1) else it.copy(fail = it.fail + 1)
    })

    var selected: String?
        get() = sp.getString("selected", null)
        set(v) { sp.edit().putString("selected", v).apply() }
    var smart: Boolean
        get() = sp.getBoolean("smart", true)
        set(v) { sp.edit().putBoolean("smart", v).apply() }
}
