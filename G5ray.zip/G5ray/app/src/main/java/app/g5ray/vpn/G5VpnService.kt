package app.g5ray.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import app.g5ray.R
import app.g5ray.core.ConfigBuilder
import app.g5ray.core.Parser
import app.g5ray.data.Store
import io.nekohasekai.libbox.*
import kotlinx.coroutines.*
import java.io.File
import java.net.NetworkInterface
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * VpnService hosting the official sing-box core (libbox, v1.10.x).
 * If your libbox build differs slightly, the compiler lists the PlatformInterface members to add/remove.
 */
class G5VpnService : VpnService(), PlatformInterface {
    companion object {
        const val ACTION_START = "app.g5ray.START"
        const val ACTION_STOP = "app.g5ray.STOP"
        const val EXTRA_IDS = "ids"
        private const val CHANNEL = "g5ray_vpn"
        @Volatile private var libboxReady = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var health: Job? = null
    private var box: BoxService? = null
    private var tun: ParcelFileDescriptor? = null
    private var ids: List<String> = emptyList()
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var ifListener: InterfaceUpdateListener? = null
    private var hadLoss = false
    private val cm by lazy { getSystemService(ConnectivityManager::class.java) }

    // ---------- lifecycle ----------
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopVpn()
            ACTION_START -> {
                ids = intent.getStringArrayExtra(EXTRA_IDS)?.toList().orEmpty()
                startFg(getString(R.string.status_connecting))
                job?.cancel()
                job = scope.launch { connect() }
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() = stopVpn()

    override fun onDestroy() {
        scope.cancel()
        closeCore()
        VpnState.flow.value = VpnStatus.Disconnected
        super.onDestroy()
    }

    private fun stopVpn() {
        job?.cancel(); health?.cancel()
        closeCore()
        VpnState.flow.value = VpnStatus.Disconnected
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(msgRes: Int) {
        closeCore()
        VpnState.flow.value = VpnStatus.Error(msgRes)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- connection logic ----------
    private suspend fun connect() {
        closeCore()
        val byId = Store.load().associateBy { it.id }
        val candidates = ids.mapNotNull { byId[it] }.take(3)
        if (candidates.isEmpty()) return fail(R.string.err_no_server)
        for (p in candidates) {
            VpnState.flow.value = VpnStatus.Connecting(p.name)
            try {
                val cfg = ConfigBuilder.build(Parser.parseAll(p.raw).first())
                Libbox.checkConfig(cfg)
                startCore(cfg)
                if (probe()) {
                    Store.record(p.id, true)
                    VpnState.flow.value = VpnStatus.Connected(p.name)
                    startFg(getString(R.string.notif_text, p.name))
                    return
                }
                Store.record(p.id, false)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Store.record(p.id, false)
            }
            closeCore()
        }
        fail(R.string.err_all_failed)
    }

    private fun startCore(config: String) {
        if (!libboxReady) {
            val base = File(filesDir, "box").apply { mkdirs() }
            Libbox.setup(base.path, base.path, cacheDir.path, false)
            libboxReady = true
        }
        val b = Libbox.newService(config, this)
        b.start()
        box = b
    }

    private fun closeCore() {
        try { box?.close() } catch (_: Throwable) {}
        box = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
    }

    /** Real end-to-end check through the tunnel (system trust store, full certificate validation). */
    private fun probe(): Boolean =
        listOf("https://cp.cloudflare.com/generate_204", "https://www.gstatic.com/generate_204").any {
            try {
                val c = URL(it).openConnection() as HttpsURLConnection
                c.connectTimeout = 6000; c.readTimeout = 6000; c.instanceFollowRedirects = false
                val ok = c.responseCode == 204
                c.disconnect(); ok
            } catch (e: Exception) { false }
        }

    /** After a network switch/loss: wait, re-check, and only reconnect if the tunnel is really dead. */
    private fun scheduleHealthCheck() {
        health?.cancel()
        health = scope.launch {
            delay(3000)
            if (VpnState.flow.value is VpnStatus.Connected && !probe()) {
                delay(5000)
                if (!probe()) { job = scope.launch { connect() } }
            }
        }
    }

    // ---------- notification ----------
    private fun startFg(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, javaClass).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat).setContentTitle("G5ray").setContentText(text)
            .setOngoing(true).addAction(0, getString(R.string.disconnect), stop).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
    }

    // ---------- PlatformInterface ----------
    override fun openTun(options: TunOptions): Int {
        check(prepare(this) == null) { "VPN permission missing" }
        val b = Builder().setSession("G5ray").setMtu(1400)
            .addAddress("172.19.0.1", 30).addAddress("fdfe:dcba:9876::1", 126)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
            .addDnsServer("172.19.0.2") // answered by sing-box (DNS hijack) and sent via DoH through the tunnel
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        val pfd = b.establish() ?: error("establish failed")
        tun = pfd
        return pfd.fd
    }

    override fun usePlatformAutoDetectInterfaceControl() = true
    override fun autoDetectInterfaceControl(fd: Int) { check(protect(fd)) { "protect failed" } }

    override fun usePlatformDefaultInterfaceMonitor() = true
    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        ifListener = listener
        val req = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build() // excludes VPNs by default
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                setUnderlyingNetworks(arrayOf(network))
                val name = cm.getLinkProperties(network)?.interfaceName ?: return
                val idx = try { NetworkInterface.getByName(name)?.index } catch (e: Exception) { null } ?: return
                ifListener?.updateDefaultInterface(name, idx)
                if (hadLoss) { hadLoss = false; scheduleHealthCheck() }
            }
            override fun onLost(network: Network) {
                hadLoss = true
                setUnderlyingNetworks(null)
                ifListener?.updateDefaultInterface("", -1)
            }
        }
        netCb = cb
        if (Build.VERSION.SDK_INT >= 31) cm.registerBestMatchingNetworkCallback(req, cb, Handler(Looper.getMainLooper()))
        else cm.requestNetwork(req, cb)
    }
    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        netCb = null; ifListener = null
    }

    override fun usePlatformInterfaceGetter() = false
    override fun getInterfaces(): NetworkInterfaceIterator = throw UnsupportedOperationException()
    override fun underNetworkExtension() = false
    override fun includeAllNetworks() = false
    override fun useProcFS() = false
    override fun findConnectionOwner(ipProtocol: Int, srcAddr: String, srcPort: Int, destAddr: String, destPort: Int): Int =
        throw UnsupportedOperationException()
    override fun packageNameByUid(uid: Int): String = throw UnsupportedOperationException()
    override fun uidByPackageName(packageName: String): Int = throw UnsupportedOperationException()
    override fun readWIFIState(): WIFIState? = null
    override fun clearDNSCache() {}
    override fun writeLog(message: String) {} // intentionally empty: no traffic metadata or secrets in logs
}
