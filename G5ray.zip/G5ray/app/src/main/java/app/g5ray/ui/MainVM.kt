package app.g5ray.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import app.g5ray.core.Parser
import app.g5ray.core.Selector
import app.g5ray.data.Profile
import app.g5ray.data.Store
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.UUID

class MainVM(app: Application) : AndroidViewModel(app) {
    val profiles = MutableStateFlow(Store.load())
    val selected = MutableStateFlow(Store.selected)
    val smart = MutableStateFlow(Store.smart)
    val latency = MutableStateFlow<Map<String, Long?>>(emptyMap())
    val testing = MutableStateFlow(false)

    fun import(text: String): Int {
        val cur = Store.load()
        val known = cur.map { it.raw }.toSet()
        val added = Parser.parseAll(text).filter { it.raw !in known }.distinctBy { it.raw }.map {
            Profile(UUID.randomUUID().toString(), it.name, it.raw, it.protocol, it.host, it.port)
        }
        if (added.isNotEmpty()) { Store.save(cur + added); profiles.value = Store.load() }
        return added.size
    }

    fun remove(id: String) { Store.save(Store.load().filter { it.id != id }); profiles.value = Store.load() }
    fun select(id: String) { Store.selected = id; selected.value = id }
    fun setSmart(b: Boolean) { Store.smart = b; smart.value = b }

    /** Returns server ids in the order the service should try them. */
    suspend fun rank(): List<String> {
        val ps = profiles.value
        if (ps.isEmpty()) return emptyList()
        if (!smart.value) return listOf((ps.firstOrNull { it.id == selected.value } ?: ps.first()).id)
        testing.value = true
        try {
            val gate = Semaphore(8)
            val res = coroutineScope {
                ps.map { p -> async { gate.withPermit { p.id to Selector.latency(p.host, p.port) } } }.awaitAll()
            }.toMap()
            latency.value = res
            return Store.load().sortedBy { Selector.score(it, res[it.id]) }.map { it.id }
        } finally { testing.value = false }
    }
}
