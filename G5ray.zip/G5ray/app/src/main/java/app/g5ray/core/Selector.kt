package app.g5ray.core

import app.g5ray.data.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/** Ranks servers by measured TCP connect latency and past connect success rate.
 *  Only valid while the VPN is OFF (otherwise probes would go through the tunnel).
 *  WireGuard is UDP, so it cannot be probed this way and is ranked by history only. */
object Selector {
    suspend fun latency(host: String, port: Int, samples: Int = 3): Long? = withContext(Dispatchers.IO) {
        val xs = (1..samples).mapNotNull {
            try {
                val t = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(host, port), 3000) }
                (System.nanoTime() - t) / 1_000_000
            } catch (e: Exception) { null }
        }.sorted()
        xs.getOrNull(xs.size / 2)
    }

    /** Lower is better. */
    fun score(p: Profile, latencyMs: Long?): Double {
        val reliability = (p.ok + 1.0) / (p.ok + p.fail + 2.0)
        val l = latencyMs?.toDouble() ?: if (p.protocol == "WireGuard") 600.0 else 1e9
        return l / reliability
    }
}
