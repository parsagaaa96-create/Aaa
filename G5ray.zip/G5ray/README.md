# G5ray (Android, Kotlin + Jetpack Compose, sing-box core)

Protocols: VLESS (tcp/ws/grpc/http/httpupgrade; TLS & REALITY), VMess, WireGuard.
Import: vless:// vmess:// wireguard:// links, WireGuard .conf, QR, clipboard, file, paste dialog.

## 1. Get the official sing-box core (libbox.aar) - one time, free
The core is not bundled; you build it from the official source (needs Go, JDK 17, Android SDK + NDK):

    git clone --branch v1.10.7 https://github.com/SagerNet/sing-box
    cd sing-box
    make lib_android            # or: go run ./cmd/internal/build_libbox -target android
    find . -name libbox.aar     # copy this file to G5ray/app/libs/libbox.aar

Make sure the build tags include `with_utls` (REALITY/fingerprints) and `with_gvisor` (default tags do).
Use v1.10.x: the app's config and PlatformInterface code target that series.

## 2. Build the APK
Android Studio (Koala+ / JDK 17): File > Open > G5ray, wait for Gradle sync, then
Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
Command line (with Gradle 8.7 installed): `gradle wrapper && ./gradlew assembleDebug`
(`assembleRelease` is signed with the debug key; use your own keystore to publish.)

## Notes
- Internet is needed once on the build machine to fetch Gradle/dependencies.
- Latency tests are TCP connect times to the server and only run while disconnected. WireGuard (UDP) can't be probed that way and is ranked by past connect history.
- Certificate verification is always on; `allowInsecure` in links is ignored.

## Easiest: build with GitHub (no local setup)
1. Create a new private GitHub repo and upload the CONTENTS of this folder (including the hidden `.github` folder).
2. Open the Actions tab > "Build APK" > Run workflow.
3. After ~15-25 min download the APK from the run's Artifacts.
